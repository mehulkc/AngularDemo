import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {HeroDetailComponent} from '../app/hero-detail/hero-detail.component';
import {ProductComponent} from '../app/product/product.component';
import {RegistrationComponent} from '../app/registration/registration.component';
import {LoginComponent} from '../app/login/login.component';

const routes: Routes = [
  { path : 'Login' , component: LoginComponent},
  { path : 'Register' , component: RegistrationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
